import bpy

from ..core.models import EditMode, Editor, SelectedPartType, SelectMode
from ..core.states import state
from ..properties.types import LightType, ObjectType
from ..properties.ui.types import (
    ControlEditorStatusType,
    LEDEditorEditModeType,
    LEDEditorStatusType,
    PosEditorStatusType,
)

# TODO: Please make this bullshit cleaner


def is_light(obj: bpy.types.Object) -> bool:
    return getattr(obj, "ld_object_type") == ObjectType.LIGHT.value


def is_led(obj: bpy.types.Object) -> bool:
    return (
        getattr(obj, "ld_object_type") == ObjectType.LIGHT.value
        and getattr(obj, "ld_light_type") == LightType.LED.value
    )


def is_led_bulb(obj: bpy.types.Object) -> bool:
    return (
        getattr(obj, "ld_object_type") == ObjectType.LIGHT.value
        and getattr(obj, "ld_light_type") == LightType.LED_BULB.value
    )


def is_fiber(obj: bpy.types.Object) -> bool:
    return (
        getattr(obj, "ld_object_type") == ObjectType.LIGHT.value
        and getattr(obj, "ld_light_type") == LightType.FIBER.value
    )


def is_dancer(obj: bpy.types.Object) -> bool:
    return getattr(obj, "ld_object_type") == ObjectType.DANCER.value


def is_human(obj: bpy.types.Object) -> bool:
    return getattr(obj, "ld_object_type") == ObjectType.HUMAN.value


def handle_autoselect_in_control_editor_dancer_mode():
    if not bpy.context:
        return
    active_obj = bpy.context.view_layer.objects.active

    if active_obj:
        if is_led_bulb(active_obj):
            active_obj = active_obj.parent.parent  # type: ignore
            active_obj.select_set(True)  # type: ignore
            bpy.context.view_layer.objects.active = active_obj

        elif is_light(active_obj):
            active_obj = active_obj.parent
            active_obj.select_set(True)  # type: ignore
            bpy.context.view_layer.objects.active = active_obj

        elif is_human(active_obj):
            active_obj = active_obj.parent
            active_obj.select_set(True)  # type: ignore
            bpy.context.view_layer.objects.active = active_obj

    # Invisible selected objects only show up in view_layer.objects.selected
    context_selected_objects: list[bpy.types.Object] = []
    for obj in bpy.context.view_layer.objects.selected:  # type: ignore
        context_selected_objects.append(obj)  # type: ignore

    # Select parent if child is selected
    for obj in context_selected_objects:
        ld_object_type: str = getattr(obj, "ld_object_type")
        if ld_object_type == ObjectType.HUMAN.value and not obj.parent.select_get():  # type: ignore
            obj.parent.select_set(True)  # type: ignore
            context_selected_objects.append(obj.parent)  # type: ignore

    # NOTE: At this stage, MIXED_LIGHT is not necessarily mixed light, it can be LED or FIBER
    # This is used to determine objects to be selected
    if active_obj and active_obj.select_get():
        if is_dancer(active_obj):
            state.selected_obj_type = SelectedPartType.DANCER

    # Maintain selected objects type
    selected_base_objs: list[bpy.types.Object] = []

    for obj in context_selected_objects:
        if is_dancer(obj) and (
            state.selected_obj_type == SelectedPartType.DANCER
            or state.selected_obj_type is None
        ):
            selected_base_objs.append(obj)

    if len(selected_base_objs) > 0:
        state.selected_obj_type = SelectedPartType.DANCER
        if len(selected_base_objs) > 1:
            selected_base_objs = [active_obj] if active_obj else []
    else:
        state.selected_obj_type = None

    # Maintain selected object names in order
    selected_base_obj_map: dict[str, bpy.types.Object] = {}
    for obj in selected_base_objs:
        selected_base_obj_map[obj.name] = obj

    new_selected_obj_names: list[str] = []
    for obj_name in state.selected_obj_names:
        if obj_name in selected_base_obj_map:
            new_selected_obj_names.append(obj_name)
            selected_base_obj_map.pop(obj_name)

    for obj_name in selected_base_obj_map.keys():
        new_selected_obj_names.append(obj_name)

    # Deselect objects that are not in the new selected object names
    selected_obj_names_set = set(new_selected_obj_names)
    for obj in context_selected_objects:
        if obj.name not in selected_obj_names_set:
            obj.select_set(False)

    # Select objects in the same relation group
    for obj in selected_base_objs:
        ld_object_type: str = getattr(obj, "ld_object_type")

        if ld_object_type == ObjectType.DANCER.value:
            for child_obj in obj.children:
                if getattr(child_obj, "ld_object_type") == ObjectType.HUMAN.value:
                    child_obj.select_set(True)

    # Activate last selected if current active object is deselected
    if (not active_obj or not active_obj.select_get()) and len(
        new_selected_obj_names
    ) > 0:
        bpy.context.view_layer.objects.active = bpy.data.objects[
            new_selected_obj_names[-1]
        ]
    if len(new_selected_obj_names) == 0:
        bpy.context.view_layer.objects.active = None  # type: ignore

    # Maintain pos editor's multi-select status
    ld_ui_pos_editor: PosEditorStatusType = getattr(
        bpy.context.window_manager, "ld_ui_pos_editor"
    )
    ld_ui_pos_editor.multi_select = len(new_selected_obj_names) > 1

    state.selected_obj_names = new_selected_obj_names


def handle_autoselect_in_control_editor_part_mode():
    if not bpy.context:
        return
    active_obj = bpy.context.view_layer.objects.active

    if active_obj:
        if is_led_bulb(active_obj):
            active_obj_parent = active_obj.parent

            if state.edit_state == EditMode.IDLE:
                active_obj = active_obj_parent
            elif active_obj_parent and (
                active_obj_parent["ld_no_status"]
                or active_obj_parent["ld_effect"] != 0
                or (active_obj_parent["ld_effect"] == 0 and not state.local_view)
            ):
                active_obj = active_obj_parent

            active_obj.select_set(True)  # type: ignore
            bpy.context.view_layer.objects.active = active_obj

        elif is_human(active_obj):
            active_obj = active_obj.parent
            if active_obj:
                active_obj.select_set(True)  # type: ignore
                bpy.context.view_layer.objects.active = active_obj

    # Invisible selected objects only show up in view_layer.objects.selected
    context_selected_objects: list[bpy.types.Object] = []
    for obj in bpy.context.view_layer.objects.selected:  # type: ignore
        context_selected_objects.append(obj)  # type: ignore

    # Select parent if child is selected
    for obj in context_selected_objects:
        ld_object_type: str = getattr(obj, "ld_object_type")
        if obj.name == "Camera":
            continue
        elif ld_object_type == ObjectType.HUMAN.value:
            if not obj.parent.select_get() and obj.parent != active_obj:  # type: ignore
                obj.parent.select_set(True)  # type: ignore
                context_selected_objects.append(obj.parent)  # type: ignore

        else:
            ld_light_type: str = getattr(obj, "ld_light_type")
            if ld_light_type == LightType.LED_BULB.value:
                if (
                    obj.parent
                    and not obj.parent.select_get()
                    and obj.parent != active_obj
                ):
                    if (
                        obj.parent["ld_no_status"]
                        or obj.parent["ld_effect"] != 0
                        or (obj.parent["ld_effect"] == 0 and not state.local_view)
                    ):
                        obj.parent.select_set(True)  # type: ignore
                        context_selected_objects.append(obj.parent)  # type: ignore

    # NOTE: At this stage, MIXED_LIGHT is not necessarily mixed light, it can be LED or FIBER
    # This is used to determine objects to be selected
    if active_obj and active_obj.select_get():
        if is_dancer(active_obj):
            state.selected_obj_type = SelectedPartType.DANCER
        elif is_led(active_obj):
            state.selected_obj_type = SelectedPartType.LED
        elif is_fiber(active_obj):
            state.selected_obj_type = SelectedPartType.FIBER
        elif is_led_bulb(active_obj):
            state.selected_obj_type = SelectedPartType.LED_BULB
        # else:
        #     state.selected_obj_type = SelectedPartType.MIXED_LIGHT

    selected_base_objs: list[bpy.types.Object] = []
    selected_fiber_objs: list[bpy.types.Object] = []
    selected_led_objs: list[bpy.types.Object] = []
    selected_led_bulb_objs: list[bpy.types.Object] = []

    for obj in context_selected_objects:
        if is_fiber(obj) and (
            state.selected_obj_type == SelectedPartType.FIBER
            or state.selected_obj_type is None
        ):
            selected_fiber_objs.append(obj)
        elif is_led(obj) and (
            state.selected_obj_type == SelectedPartType.LED
            or state.selected_obj_type is None
        ):
            selected_led_objs.append(obj)
        elif is_led_bulb(obj) and (
            (
                state.selected_obj_type == SelectedPartType.LED_BULB
                or state.selected_obj_type is None
            )
            and obj.parent
            and not obj.parent["ld_no_status"]
            and obj.parent["ld_effect"] == 0
        ):
            selected_led_bulb_objs.append(obj)

    # Maintain selected objects type
    # if len(selected_led_objs) > 0 and len(selected_fiber_objs) > 0:
    #     state.selected_obj_type = SelectedPartType.MIXED_LIGHT
    #     selected_base_objs = [*selected_led_objs, *selected_fiber_objs]
    #
    # elif len(selected_led_objs) > 0:
    if len(selected_led_objs) > 0:
        state.selected_obj_type = SelectedPartType.LED
        selected_base_objs = selected_led_objs

    elif len(selected_fiber_objs) > 0:
        state.selected_obj_type = SelectedPartType.FIBER
        selected_base_objs = selected_fiber_objs

    elif len(selected_led_bulb_objs) > 0:
        state.selected_obj_type = SelectedPartType.LED_BULB
        selected_base_objs = selected_led_bulb_objs

    else:
        state.selected_obj_type = None

    # Maintain selected object names in order
    selected_base_obj_map: dict[str, bpy.types.Object] = {}
    for obj in selected_base_objs:
        selected_base_obj_map[obj.name] = obj

    new_selected_obj_names: list[str] = []
    for obj_name in state.selected_obj_names:
        if obj_name in selected_base_obj_map:
            new_selected_obj_names.append(obj_name)
            selected_base_obj_map.pop(obj_name)

    for obj_name in selected_base_obj_map:
        new_selected_obj_names.append(obj_name)

    # Deselect objects that are not in the new selected object names
    selected_obj_names_set = set(new_selected_obj_names)
    for obj in context_selected_objects:
        if obj.name not in selected_obj_names_set:
            obj.select_set(False)

    # Select objects in the same relation group
    for obj in selected_base_objs:
        ld_object_type: str = getattr(obj, "ld_object_type")
        ld_light_type: str = getattr(obj, "ld_light_type")

        if ld_object_type == ObjectType.LIGHT.value:
            if ld_light_type == LightType.LED.value:
                for child_obj in obj.children:
                    child_obj.select_set(True)

    # Activate last selected if current active object is deselected
    if (not active_obj or not active_obj.select_get()) and len(
        new_selected_obj_names
    ) > 0:
        bpy.context.view_layer.objects.active = bpy.data.objects[
            new_selected_obj_names[-1]
        ]
    if len(new_selected_obj_names) == 0:
        bpy.context.view_layer.objects.active = None  # type: ignore

    # Maintain control editor's multi-select status
    ld_ui_control_editor: ControlEditorStatusType = getattr(
        bpy.context.window_manager, "ld_ui_control_editor"
    )
    ld_ui_control_editor.multi_select = len(new_selected_obj_names) > 1

    sorted_selected_obj_names = sorted(state.selected_obj_names.copy())
    sorted_new_selected_obj_names = sorted(new_selected_obj_names.copy())
    if sorted_selected_obj_names != sorted_new_selected_obj_names:
        # Don't trigger update here
        ld_ui_control_editor["multi_select_effect"] = -1  # type: ignore
        ld_ui_control_editor["multi_select_color"] = -1  # type: ignore
        ld_ui_control_editor["multi_select_alpha"] = 150  # type: ignore

    state.selected_obj_names = new_selected_obj_names


def handle_autoselect_in_control_editor():
    match state.selection_mode:
        case SelectMode.PART_MODE:
            handle_autoselect_in_control_editor_part_mode()
        case SelectMode.DANCER_MODE:
            handle_autoselect_in_control_editor_dancer_mode()

    # active_obj = bpy.context.view_layer.objects.active
    #
    # if active_obj:
    #     if is_led_bulb(active_obj):
    #         active_obj = active_obj.parent
    #         active_obj.select_set(True)
    #         bpy.context.view_layer.objects.active = active_obj
    #
    #     if is_human(active_obj):
    #         active_obj = active_obj.parent
    #         active_obj.select_set(True)
    #         bpy.context.view_layer.objects.active = active_obj
    #
    # # Invisible selected objects only show up in view_layer.objects.selected
    # context_selected_objects: list[bpy.types.Object] = []
    # for obj in bpy.context.view_layer.objects.selected:  # type: ignore
    #     context_selected_objects.append(obj)  # type: ignore
    #
    # # Select parent if child is selected
    # for obj in context_selected_objects:
    #     ld_object_type: str = getattr(obj, "ld_object_type")
    #     if ld_object_type == ObjectType.HUMAN.value:
    #         if not obj.parent.select_get() and obj.parent != active_obj:
    #             obj.parent.select_set(True)
    #             context_selected_objects.append(obj.parent)
    #
    #     else:
    #         ld_light_type: str = getattr(obj, "ld_light_type")
    #         if ld_light_type == LightType.LED_BULB.value:
    #             if not obj.parent.select_get() and obj.parent != active_obj:
    #                 obj.parent.select_set(True)
    #                 context_selected_objects.append(obj.parent)
    #
    # # NOTE: At this stage, MIXED_LIGHT is not necessarily mixed light, it can be LED or FIBER
    # # This is used to determine objects to be selected
    # if active_obj and active_obj.select_get():
    #     if is_dancer(active_obj):
    #         state.selected_obj_type = SelectedPartType.DANCER
    #     else:
    #         state.selected_obj_type = SelectedPartType.MIXED_LIGHT
    #
    # selected_base_objs: list[bpy.types.Object] = []
    # selected_fiber_objs: list[bpy.types.Object] = []
    # selected_led_objs: list[bpy.types.Object] = []
    # selected_dancer_objs: list[bpy.types.Object] = []
    #
    # for obj in context_selected_objects:
    #     if is_fiber(obj) and state.selected_obj_type != SelectedPartType.DANCER:
    #         selected_fiber_objs.append(obj)
    #     elif is_led(obj) and state.selected_obj_type != SelectedPartType.DANCER:
    #         selected_led_objs.append(obj)
    #     elif is_dancer(obj) and (
    #         state.selected_obj_type == SelectedPartType.DANCER
    #         or state.selected_obj_type is None
    #     ):
    #         selected_dancer_objs.append(obj)
    #
    # # Maintain selected objects type
    # if len(selected_led_objs) > 0 and len(selected_fiber_objs) > 0:
    #     state.selected_obj_type = SelectedPartType.MIXED_LIGHT
    #     selected_base_objs = [*selected_led_objs, *selected_fiber_objs]
    #
    # elif len(selected_led_objs) > 0:
    #     state.selected_obj_type = SelectedPartType.LED
    #     selected_base_objs = selected_led_objs
    #
    # elif len(selected_fiber_objs) > 0:
    #     state.selected_obj_type = SelectedPartType.FIBER
    #     selected_base_objs = selected_fiber_objs
    #
    # elif len(selected_dancer_objs) > 0:
    #     state.selected_obj_type = SelectedPartType.DANCER
    #     if len(selected_dancer_objs) > 1:
    #         selected_base_objs = [active_obj] if active_obj else []
    #     else:
    #         selected_base_objs = selected_dancer_objs
    #
    # else:
    #     state.selected_obj_type = None
    #
    # # Maintain selected object names in order
    # selected_base_obj_map: dict[str, bpy.types.Object] = {}
    # for obj in selected_base_objs:
    #     selected_base_obj_map[obj.name] = obj
    #
    # new_selected_obj_names: list[str] = []
    # for obj_name in state.selected_obj_names:
    #     if obj_name in selected_base_obj_map:
    #         new_selected_obj_names.append(obj_name)
    #         selected_base_obj_map.pop(obj_name)
    #
    # for obj_name in selected_base_obj_map:
    #     new_selected_obj_names.append(obj_name)
    #
    # # Deselect objects that are not in the new selected object names
    # selected_obj_names_set = set(new_selected_obj_names)
    # for obj in context_selected_objects:
    #     if obj.name not in selected_obj_names_set:
    #         obj.select_set(False)
    #
    # # Select objects in the same relation group
    # for obj in selected_base_objs:
    #     ld_object_type: str = getattr(obj, "ld_object_type")
    #     ld_light_type: str = getattr(obj, "ld_light_type")
    #
    #     if ld_object_type == ObjectType.LIGHT.value:
    #         if ld_light_type == LightType.LED.value:
    #             for child_obj in obj.children:
    #                 child_obj.select_set(True)
    #
    #     elif ld_object_type == ObjectType.DANCER.value:
    #         for child_obj in obj.children:
    #             if getattr(child_obj, "ld_object_type") == ObjectType.HUMAN.value:
    #                 child_obj.select_set(True)
    #
    # # Activate last selected if current active object is deselected
    # if (not active_obj or not active_obj.select_get()) and len(
    #     new_selected_obj_names
    # ) > 0:
    #     bpy.context.view_layer.objects.active = bpy.data.objects[
    #         new_selected_obj_names[-1]
    #     ]
    # if len(new_selected_obj_names) == 0:
    #     bpy.context.view_layer.objects.active = None  # type: ignore
    #
    # # Maintain control editor's multi-select status
    # ld_ui_control_editor: ControlEditorStatusType = getattr(
    #     bpy.context.window_manager, "ld_ui_control_editor"
    # )
    # ld_ui_control_editor.multi_select = (
    #     len(new_selected_obj_names) > 1
    #     and state.selected_obj_type != SelectedPartType.DANCER
    # )
    #
    # sorted_selected_obj_names = sorted(state.selected_obj_names.copy())
    # sorted_new_selected_obj_names = sorted(new_selected_obj_names.copy())
    # if sorted_selected_obj_names != sorted_new_selected_obj_names:
    #     # Don't trigger update here
    #     ld_ui_control_editor["multi_select_color"] = -1  # type: ignore
    #     ld_ui_control_editor["multi_select_alpha"] = 128  # type: ignore
    #
    # state.selected_obj_names = new_selected_obj_names


def handle_autoselect_in_pos_editor():
    if not bpy.context:
        return
    active_obj = bpy.context.view_layer.objects.active

    if active_obj:
        if is_led_bulb(active_obj):
            active_obj = active_obj.parent.parent  # type: ignore
            active_obj.select_set(True)  # type: ignore
            bpy.context.view_layer.objects.active = active_obj

        elif is_light(active_obj):
            active_obj = active_obj.parent
            active_obj.select_set(True)  # type: ignore
            bpy.context.view_layer.objects.active = active_obj

        elif is_human(active_obj):
            active_obj = active_obj.parent
            active_obj.select_set(True)  # type: ignore
            bpy.context.view_layer.objects.active = active_obj

    # Invisible selected objects only show up in view_layer.objects.selected
    context_selected_objects: list[bpy.types.Object] = []
    for obj in bpy.context.view_layer.objects.selected:  # type: ignore
        context_selected_objects.append(obj)  # type: ignore

    # Select parent if child is selected
    for obj in context_selected_objects:
        ld_object_type: str = getattr(obj, "ld_object_type")
        if ld_object_type == ObjectType.HUMAN.value and not obj.parent.select_get():  # type: ignore
            obj.parent.select_set(True)  # type: ignore
            context_selected_objects.append(obj.parent)  # type: ignore

    # NOTE: At this stage, MIXED_LIGHT is not necessarily mixed light, it can be LED or FIBER
    # This is used to determine objects to be selected
    if active_obj and active_obj.select_get():
        if is_dancer(active_obj):
            state.selected_obj_type = SelectedPartType.DANCER

    # Maintain selected objects type
    selected_base_objs: list[bpy.types.Object] = []

    for obj in context_selected_objects:
        if is_dancer(obj) and (
            state.selected_obj_type == SelectedPartType.DANCER
            or state.selected_obj_type is None
        ):
            selected_base_objs.append(obj)

    if len(selected_base_objs) > 0:
        state.selected_obj_type = SelectedPartType.DANCER

    else:
        state.selected_obj_type = None

    # Maintain selected object names in order
    selected_base_obj_map: dict[str, bpy.types.Object] = {}
    for obj in selected_base_objs:
        selected_base_obj_map[obj.name] = obj

    new_selected_obj_names: list[str] = []
    for obj_name in state.selected_obj_names:
        if obj_name in selected_base_obj_map:
            new_selected_obj_names.append(obj_name)
            selected_base_obj_map.pop(obj_name)

    for obj_name in selected_base_obj_map.keys():
        new_selected_obj_names.append(obj_name)

    # Deselect objects that are not in the new selected object names
    selected_obj_names_set = set(new_selected_obj_names)
    for obj in context_selected_objects:
        if obj.name not in selected_obj_names_set:
            obj.select_set(False)

    # Select objects in the same relation group
    for obj in selected_base_objs:
        ld_object_type: str = getattr(obj, "ld_object_type")

        if ld_object_type == ObjectType.DANCER.value:
            for child_obj in obj.children:
                if getattr(child_obj, "ld_object_type") == ObjectType.HUMAN.value:
                    child_obj.select_set(True)

    # Activate last selected if current active object is deselected
    if (not active_obj or not active_obj.select_get()) and len(
        new_selected_obj_names
    ) > 0:
        bpy.context.view_layer.objects.active = bpy.data.objects[
            new_selected_obj_names[-1]
        ]
    if len(new_selected_obj_names) == 0:
        bpy.context.view_layer.objects.active = None  # type: ignore

    # Maintain pos editor's multi-select status
    ld_ui_pos_editor: PosEditorStatusType = getattr(
        bpy.context.window_manager, "ld_ui_pos_editor"
    )
    ld_ui_pos_editor.multi_select = len(new_selected_obj_names) > 1

    sorted_selected_obj_names = sorted(state.selected_obj_names.copy())
    sorted_new_selected_obj_names = sorted(new_selected_obj_names.copy())
    if sorted_selected_obj_names != sorted_new_selected_obj_names:
        # Don't trigger update here
        ld_ui_pos_editor["multi_select_delta_transform"] = (0.0, 0.0, 0.0)  # type: ignore
        ld_ui_pos_editor["multi_select_delta_transform_ref"] = (0.0, 0.0, 0.0)  # type: ignore

    state.selected_obj_names = new_selected_obj_names


def handle_autoselect_in_led_editor_edit_mode():
    # WARNING: It should by fine that we don't consider the case when objects
    # other than LED bulbs are selected in edit mode since they are filterd out
    # and that local view if toggled on (maybe we need to ban the keymap for local view)
    if not bpy.context:
        return
    active_obj = bpy.context.view_layer.objects.active

    original_selected_obj_names = sorted(state.selected_obj_names.copy())

    selected_obj_names: list[str] = []
    for obj in bpy.context.selected_objects:
        ld_object_type: str = getattr(obj, "ld_object_type")
        if ld_object_type == ObjectType.LIGHT.value:
            ld_light_type: str = getattr(obj, "ld_light_type")
            if ld_light_type == LightType.LED_BULB.value:
                selected_obj_names.append(obj.name)

    state.selected_obj_names = selected_obj_names

    for obj in bpy.context.selected_objects:
        if obj.name not in state.selected_obj_names:
            obj.select_set(False)

    if (active_obj and not active_obj.select_get()) and len(
        state.selected_obj_names
    ) > 0:
        bpy.context.view_layer.objects.active = bpy.data.objects[
            state.selected_obj_names[-1]
        ]
    if len(state.selected_obj_names) == 0:
        bpy.context.view_layer.objects.active = None  # type: ignore

    # TODO: maintain multi-select of led editor
    ld_ui_led_editor: LEDEditorStatusType = getattr(
        bpy.context.window_manager, "ld_ui_led_editor"
    )
    ld_ui_led_editor.multi_select = len(state.selected_obj_names) > 1

    sorted_selected_obj_names = sorted(state.selected_obj_names)
    if sorted_selected_obj_names != original_selected_obj_names:
        # Don't trigger update here
        ld_ui_led_editor["multi_select_color"] = -1  # type: ignore
        ld_ui_led_editor["multi_select_alpha"] = 150  # type: ignore


def handle_autoselect_in_led_editor():
    if not bpy.context:
        return
    ld_ui_led_editor: LEDEditorStatusType = getattr(
        bpy.context.window_manager, "ld_ui_led_editor"
    )

    if ld_ui_led_editor.edit_mode == LEDEditorEditModeType.EDIT.value:
        handle_autoselect_in_led_editor_edit_mode()
        return

    active_obj = bpy.context.view_layer.objects.active

    # NOTE: Keep selection in led editor
    if active_obj and not active_obj.select_get():
        active_obj.select_set(True)

    if active_obj:
        if is_light(active_obj) and not is_led(active_obj):
            active_obj = active_obj.parent
            active_obj.select_set(True)  # type: ignore
            bpy.context.view_layer.objects.active = active_obj

        elif is_human(active_obj):
            active_obj = active_obj.parent  # type: ignore
            active_obj.select_set(True)  # type: ignore
            bpy.context.view_layer.objects.active = active_obj

    # Invisible selected objects only show up in view_layer.objects.selected
    context_selected_objects: list[bpy.types.Object] = []
    for obj in bpy.context.view_layer.objects.selected:  # type: ignore
        context_selected_objects.append(obj)  # type: ignore

    # Select parent if child is selected
    for obj in context_selected_objects:
        ld_object_type: str = getattr(obj, "ld_object_type")
        if ld_object_type == ObjectType.HUMAN.value:
            if not obj.parent.select_get():  # type: ignore
                obj.parent.select_set(True)  # type: ignore
                context_selected_objects.append(obj.parent)  # type: ignore

        else:
            ld_light_type: str = getattr(obj, "ld_light_type")
            if ld_light_type == LightType.LED_BULB.value:
                if not obj.parent.select_get():  # type: ignore
                    obj.parent.select_set(True)  # type: ignore
                    context_selected_objects.append(obj.parent)  # type: ignore

    # NOTE: At this stage, MIXED_LIGHT is not necessarily mixed light, it can be LED or FIBER
    # This is used to determine objects to be selected
    if active_obj and active_obj.select_get():
        if is_dancer(active_obj):
            state.selected_obj_type = SelectedPartType.DANCER
        elif is_led(active_obj):
            state.selected_obj_type = SelectedPartType.LED

    for obj in context_selected_objects:
        if obj != active_obj:
            obj.select_set(False)

    # Select objects in the same relation group
    if active_obj:
        if is_led(active_obj):
            for child_obj in active_obj.children:
                child_obj.select_set(True)

        elif is_dancer(active_obj):
            for child_obj in active_obj.children:
                if getattr(child_obj, "ld_object_type") == ObjectType.HUMAN.value:
                    child_obj.select_set(True)

    # Maintain led editor's multi-select status
    if state.selected_obj_type == SelectedPartType.LED:
        # Don't trigger update dancer here
        ld_model_name = getattr(active_obj, "ld_model_name")
        ld_dancer_name = getattr(active_obj, "ld_dancer_name")
        ld_ui_led_editor["edit_model"] = state.model_dancer_index_map[ld_model_name].index  # type: ignore
        ld_ui_led_editor["edit_dancer"] = state.dancer_part_index_map[ld_dancer_name].index  # type: ignore
        ld_ui_led_editor.edit_part = getattr(active_obj, "ld_part_name")

    elif state.selected_obj_type == SelectedPartType.DANCER:
        ld_model_name = getattr(active_obj, "ld_model_name")
        ld_ui_led_editor["edit_model"] = state.model_dancer_index_map[ld_model_name].index  # type: ignore
        ld_ui_led_editor.edit_dancer = getattr(active_obj, "ld_dancer_name")


def obj_panel_autoselect_handler(scene: bpy.types.Scene):
    """
    Auto-select a group of lights if one of each is selected.
    When a human object is selected, its dancer will also be auto-selected and vice versa.
    """
    # if bpy.context.object is None:  # type: ignore
    #     return

    match state.editor:
        case Editor.CONTROL_EDITOR:
            handle_autoselect_in_control_editor()
        case Editor.POS_EDITOR:
            handle_autoselect_in_pos_editor()
        case Editor.LED_EDITOR:
            handle_autoselect_in_led_editor()


def mount():
    bpy.app.handlers.depsgraph_update_pre.append(obj_panel_autoselect_handler)


def unmount():
    try:
        bpy.app.handlers.depsgraph_update_pre.remove(obj_panel_autoselect_handler)
    except:
        pass
