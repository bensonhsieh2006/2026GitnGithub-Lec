import bpy

from ...core.models import EditMode, Editor
from ...core.states import state
from ...properties.types import ObjectType, PositionPropertyType
from ...properties.ui.types import PosEditorStatusType


class PosEditor(bpy.types.Panel):
    bl_label = "Position"
    bl_parent_id = "VIEW_PT_LightDance_LightDance"
    bl_idname = "VIEW_PT_LightDance_PosEditor"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "LightDance"
    bl_options = {"HIDE_HEADER"}

    @classmethod
    def poll(cls, context: bpy.types.Context | None):
        return state.ready and state.sync and state.editor == Editor.POS_EDITOR

    def draw(self, context: bpy.types.Context | None):
        if not context:
            return
        layout = self.layout
        layout.enabled = not state.shifting and not state.requesting

        row = layout.row()
        row.label(text="Position Editor")

        editing = state.edit_state == EditMode.EDITING
        properties_enabled = editing and not state.playing

        if state.current_editing_detached and editing:
            row = layout.row()
            row.enabled = not state.playing
            row.label(text="Detached", icon="ERROR")
            row.operator("lightdance.attach_editing_pos_frame", icon="PLAY")

        # check if object is selected
        obj = context.object
        if obj is None:  # type: ignore
            return

        ld_object_type: str = getattr(obj, "ld_object_type")
        if ld_object_type != ObjectType.DANCER.value or not obj.select_get():
            return

        column = layout.column()
        column.enabled = properties_enabled

        ld_ui_pos_editor: PosEditorStatusType = getattr(
            context.window_manager, "ld_ui_pos_editor"
        )

        if ld_ui_pos_editor.multi_select:
            column.prop(
                ld_ui_pos_editor, "multi_select_delta_transform", text="Delta Transform"
            )

        else:
            position: PositionPropertyType = getattr(context.object, "ld_position")
            column.prop(position, "location", text="Transform")
            column.prop(position, "rotation", text="Rotation")

            row2 = column.row(align=True)
            row2.prop(position, "is_none", text="Has Status", invert_checkbox=True)


def register():
    bpy.utils.register_class(PosEditor)


def unregister():
    bpy.utils.unregister_class(PosEditor)
